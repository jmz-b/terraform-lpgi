import json

def handler(event, context):
    return {'statusCode': 404, 'headers': {}, 'body': json.dumps(event)}
